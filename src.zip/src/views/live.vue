  <template>
    <div class="main">
      <header>
        <div class="header">
					<a style="position:relative;" href="javscript:;">
						<img class="uname" src="@/components/icon/wml_miniapp_default.png">
						<span style="left:1.125rem;top:0.0125rem;position:absolute;color:#666" class="mui-icon mui-icon-person"></span>
					</a>
					<span>生活圈</span>
					<span class="mui-icon mui-icon-search"></span>
				</div>
      </header>
      <!-- 11 -->
      <div class="mui-content">
			<div id="slider" class="mui-slider">
				<div id="sliderSegmentedControl" class="mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
					<a class="mui-control-item" href="#item1mobile">
						附近
					</a>
					<a class="mui-control-item mui-active" href="#item2mobile">
						推荐
					</a>
					<a class="mui-control-item" href="#item3mobile">
						关注
					</a>
				</div>
				<div id="sliderProgressBar" class="mui-slider-progress-bar mui-col-xs-4 ">
					<span class="ProgressBarSpan"></span>
				</div>
				<div class="mui-slider-group">
					<div id="item1mobile" class="mui-slider-item mui-control-content">
						<div id="scroll1" class="mui-scroll-wrapper">
							<div class="mui-scroll">
								<div id="Login" :class="dno==true?'dno':''">
									<img src="@/components/icon/loginlogo.png" alt="">
									<p>当前操作需要您的登录</p>
									<p>登录查看更多精彩内容</p>
									<a class="loginNow" href="/login">
										立即登录
									</a>
								</div>
								<div class="zhuanqu" :class="dshow==true?'dshow':''">
									333
								</div>
							</div>
						</div>
					</div>
					<div id="item2mobile" class="mui-slider-item mui-control-content mui-active">
						<div id="scroll2" class="mui-scroll-wrapper">
							<div class="mui-scroll">
								<div class="zhuanqu">
									<div class="newPerson_top">
										<a class="Top" href="javascript:;">
											<span>达人榜单</span>
										</a>
										<a class="more" href="javascript:;">更多&gt;</a>
									</div>
									<!-- 啥同仁堂 -->
									<div id="msdrb" class="mui-scroll-wrapper mui-slider-indicator 		   	mui-segmented-control mui-segmented-control-inverted">
										<div class="mui-scroll">
											<a class="mui-control-item " href="javascript:;" data-wid="tab-top-subpage-1.html">
												<img class="purl_img" :src="pur_img" alt="">
																	<span class="purl_c">超人气榜单</span>
																	<p class="purl_f" v-text="purl_f"></p>
																	<span class="purl_t" v-text="`推荐了${purl_t}家店`"></span>
											</a>
											<a class="mui-control-item" href="javascript:;" data-wid="tab-top-subpage-2.html">
												<img class="purl_img" src="img/pushLive/sk01.jpg" alt="">
																	<span class="purl_c purl_cbg">#大胃王,来战#</span>
																	<p class="purl_f">上海人气烧烤店,排队也要去</p>
																	<span class="purl_t">推荐了8家店</span>
											</a>
											<a class="mui-control-item" href="javascript:;" data-wid="tab-top-subpage-3.html">
												<img class="purl_img" src="img/pushLive/ct01.jpg" alt="">
																	<span class="purl_c purl_cbg">#走!攒个屁#</span>
																	<p class="purl_f">盘点广州让你扶墙而出的自助餐厅</p>
																	<span class="purl_t">推荐了8家店</span>
											</a>
											<a class="mui-control-item" href="javascript:;" data-wid="tab-top-subpage-4.html">
												<img class="purl_img" src="img/pushLive/sjgz01.jpg" alt="">
																	<span class="purl_c purl_cbg">#寻味老广州#</span>
																	<p class="purl_f">舌尖上的广州之本地帮菜</p>
																	<span class="purl_t" >推荐了8家店</span>
											</a>
											<a class="mui-control-item purlMore" href="javascript:;" data-wid="tab-top-subpage-5.html">
												<p>MORE</p>
												<p>查看更多</p>
											</a>
										</div>
									</div>
									<!-- end -->
									<div style="width:100%">
										<p style="margin:1.25rem 25% 0.5rem;height:0.0125rem;width:12rem;border:1px #ddd solid;"></p>
									</div>
									<div id="liveContainer">
										<div class="live" v-for="item of 8" :key="item.i">
											<a href="javascript:;">
													<img class="liveImg" src="img/pushlive/l0.jpg" alt="">
														<p class="live_title">化为饿龙,把美食通通消灭HLK饿龙</p>
														<span style="font-size:1.125rem;" class="mui-icon-extra mui-icon-extra-card location"></span>
														<span style="margin:0;" class="location">万寿路(HLK美食店)</span>
											</a>
											<div class="person_contant">
												<a href="javascript:;">
													<span style="font-size:1.125rem;color:#999" class="mui-icon mui-icon-contact contant"></span>
													<span style="color:#999;font-size:0.8rem;">美评</span>
												</a>
												<div>
													<span style="font-size:1rem;color:#999" class="mui-icon-extra mui-icon-extra-like"></span>
													<span style="color:#999;margin-right:0.125rem;">1</span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="item3mobile" class="mui-slider-item mui-control-content">
						<div id="scroll3" class="mui-scroll-wrapper">
							<div class="mui-scroll">
								<div id="Login" :class="dno==true?'dno':''">
									<img src="@/components/icon/loginlogo.png" alt="">
									<p>当前操作需要您的登录</p>
									<p>登录查看更多精彩内容</p>
									<a class="loginNow" href="/login">
										立即登录
									</a>
								</div>
								<div class="zhuanqu" :class="dshow==true?'dshow':''">
								123
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>

		
      
      
      <Footer></Footer>
    </div>
  </template>      
<script>
import Footer from '@/components/footer.vue'
import { setInterval } from 'timers';
export default {
  data(){
    return{
			dno:false,
			dshow:true,
			pur_img:"img/pushLive/shanhai.jpg",
			purl_f:"广州|美食人气榜TOP10",
			purl_t:7,
    }
  },
  created(){
		var uname = sessionStorage.getItem("uname");
		if(uname){
			this.dno=true;
			this.dshow = false;
		}else{
			this.dno=false;
			this.dshow =true;
		}
		this.$store.state.num=2;
		mui('body').on('tap','a',function(){
      window.top.location.href=this.href;
		});
		var purI = 0;
		setInterval(()=>{
			var pur_img=["img/pushLive/shanhai.jpg","img/pushLive/cof.jpg","img/pushLive/riliao.jpg"],purl_f=["广州 | 美食人气榜TOP10","春香曼妙,品味轻奢的慢生活","吃货萌要找的魔都畅吃日料"],purl_t=[7,10,7]
			if(purI>=purl_f.length){
				purI=0
			}
			// console.log(purI)
			this.purl_f = purl_f[purI];
			this.purl_t = purl_t[purI];
			this.pur_img =pur_img[purI];
			purI++;
		},3000);

  },
  mounted(){
    mui.init({
				swipeBack: false
			});
			(function($) {
				$('.mui-scroll-wrapper').scroll({
					indicators: false //是否显示滚动条
				});
			})(mui);
			mui('.mui-slider').slider().stopped = false;

			
  },
  methods:{
   
  },
  components:{
   Footer
  }
}
</script>
<style scoped>
.mui-control-content {
				background-color: white;
				min-height:786px;
	}
header{
		top:0;
		width:100%;
		height:3.5rem;
    position: fixed;
    z-index:99;
		color:#fff;
		background:linear-gradient(left,#ff8500,#ff5a00);
  }
.header{
	position: absolute;
	bottom:0.55rem;
	width:100%;
	display: flex;
	justify-content: space-between;
	align-items: flex-end;
	}
	.uname{
		margin-left:1rem;
		margin-bottom:-0.25rem;
		display:inline-block;
		width:1.8rem;
		height:1.8rem;
		border-radius:50%;
	}
	.mui-icon-search{
		padding-right:1rem;
	}
  .mui-segmented-control.mui-segmented-control-inverted .mui-control-item.mui-active{
    color:#ff5a00;
  }
	#slider .mui-control-item{
		font-size:1rem;
		font-weight:bold;
	}
  #sliderSegmentedControl{
		position: fixed;
    background: #fff;
		top:3.5rem;
  }
  #sliderSegmentedControl,#sliderProgressBar{
		position:fixed;
		top:3.5rem;
    z-index:99;
  }
	.ProgressBarSpan{
		display:inline-block;
		position:absolute;
		top:0;
		left:42%;
		width:0.8rem;
		height:0.15rem;
		background:#ff5a00;
	}
  .mui-segmented-control.mui-segmented-control-inverted ~ .mui-slider-progress-bar{
    background-color: #fff;
  }
  #sliderProgressBar{
    margin-top:2.35rem;
  }
  .mui-scroll-wrapper{
		top:7rem;
	}

	.newPerson_top{
	position: relative;
	text-align:left;
}
#Login{
	padding:0 0.85rem;
	text-align: center;
}
#Login p:nth-child(2){
	color:#000;
	font:1rem bold;
}
#Login p:nth-child(3){
	color:#999;
	font:0.8rem bold;
}
#Login .loginNow{
	display:inline-block;
	color:#000;
	width:15rem;
	height:3rem;
	line-height:3rem;
	border-radius:2rem;
	font-size: 1.2rem;
	border:1px #ccc solid;
}
/* 专区 */
.zhuanqu{
	padding:0 0.85rem;
}

.Top{
	color: #000;
	font-size:1.12rem;
	font-weight:700;
	margin-left:0.18rem;
}
.more{
	position:absolute;
	color:#999;
	font-size:0.8rem;
	font-weight:bold;
	right:0.4rem;
}
#msdrb{
	top:0;
	left:0;
	background-color:#fff;
	margin-top:0.55rem;
	width:100%;
	height:10.5rem;
	position: relative;
	overflow:hidden;
}
#scroll2 .mui-segmented-control.mui-scroll-wrapper .mui-control-item{
	width:8rem;
	border-radius:3%;
	padding:0;
	margin:0 0.5rem 0 0;
	height:10.5rem;
	position: relative;
	border:1px #ccc solid;
}
#scroll2 .mui-segmented-control.mui-scroll-wrapper .mui-scroll .purl_f{
	white-space: normal;
} 
.purl_c{
	display: inline-block;
	color:#fff;
	background:#ff5a00;
	width:5rem;
	height:1.45rem;
	font-size: 0.6rem;
	text-align: center;
	line-height:1.45rem;
	position:absolute;
	top:4.25rem;
	left:0.7rem;
	border-radius: 0.18rem;
	box-shadow:10px 10px 5 #000;
}
.purl_cbg{
	background-color:#333335;
	width:6.25rem;
	color:#fee0ac;
}
.purl_f{
	color:#000;
	font-size:0.7rem;
	font-weight:700;
	position:absolute;
	width:6rem;
	text-align: left;
	top:6.25rem;
	left:0.7rem;
}
#scroll2 .mui-segmented-control .mui-control-item .purl_f{
	line-height:1.15rem;
}
.purl_t{
	position:absolute;
	text-align: left;
	left:0.7rem;
	font-size:0.6rem;
	color:#999;
	bottom:0rem;
}
 #scroll2 .mui-slider .mui-slider-group .mui-slider-item img,.purl_img{
	width:7.90rem;
	height:5rem;
} 

.purlMore>p{
	font-size: 0.6rem;
	line-height:2rem;
}
.purlMore>p:first-child{
	font-size:0.925rem;
	color:#000;
	margin-top:3.5rem;
}
#liveContainer{
	display:flex;
	flex-wrap: wrap;
	justify-content: space-between;
	width:100%;
	box-sizing: border-box;
}
#liveContainer .live{
	margin-top:0.5rem;
	width:48%;
	border:1px #999 solid;
	text-align:left;
	text-overflow: ellipsis;/*溢出添加省略号*/
}
#liveContainer .live_title{
	font-size:0.8rem;
	font-weight:700;
	color:#000;
	margin-left:0.5rem;
	margin-bottom:0;
}
#liveContainer .location{
	margin-left:0.5rem;
	font-size: 0.6rem;
	color:#999;
}
.person_contant{
	display: flex;
	justify-content: space-between;
	margin-left:0.3rem;
}
.dno{
	display: none;
}

.dshow{
	display: none;
}
</style>
