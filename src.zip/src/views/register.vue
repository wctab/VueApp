<template>
  <div style="background:#fff">
    <header class="header">
        <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>
    </header>
    <div class="mui-content">
        <h4 style="padding-top:0.45rem;margin-bottom:1.5rem;background:#fff;">账号注册</h4>
        <form class="mui-input-group">
            <div class="mui-input-row">
                <label>帐号</label>
                <input type="text" v-model="username" 
                v-focus="true" class="mui-input-clear" placeholder="请输入帐号名" id="username">
            </div>
            <div class="mui-input-row">
                <label>密码</label>
                <input type="text" v-model="password" class="mui-input-password" placeholder="请输入密码" id="password">
            </div>
            <div class="mui-input-row">
                <label>再次确认密码</label>
                <input type="text" v-model="password2" class="mui-input-clear" placeholder="请再次确认密码" id="password">
            </div>
        </form>
        <div class="mui-content-padded" align="center">
            <button type="button" class="mui-btn" :disabled="disabled" :class="em==true?'':'loginactive'" @click="register">注册</button>
        </div>
        <div class="telReg">
          注册即表示您同意某付宝及客户端服务协议,某付宝隐私权政策和淘某宝服务协议
        </div>
    </div>
  </div>
</template>
<script>
import { setTimeout } from 'timers';
export default {
  data(){
    return{
      em:true,
      disabled:true,
      username:'',
      password:'',
      password2:''
    }
  },
  created(){
  },
  mounted(){
    
  },
  methods:{
    register(){
        if(this.password2 !==this.password){
          mui.toast("请再次确认密码");
          return;
        }
        mui.ajax("http://127.0.0.1:4000/user/register",{
          data:{
            uname:this.username,
            upwd:this.password
          },
          dataType:"json",
          type:"POST",
          timeout:10000,
          success:(result)=>{
            console.log(result);
            if(result.code==200){
              mui.toast(result.msg)
              setTimeout(function(){
                mui.back();
              },1000)
            }else if(result.code==-1){
                mui.toast(result.msg);
            }
          },
          error:()=>{
            mui.toast("注册出错,请重新注册")
          }
        })
    },
    pd(){
      if(this.username.trim() !=="" && this.password.trim() !==""){
        this.em=false;
        this.disabled = false;
      }else{
        this.em=true;
        this.disabled = true;
      }
    }
  },
  watch:{
    username(){
      this.pd();
    },
    password(){
      this.pd();
    }
  }
}
</script>
<style scoped>
.header{
  padding: 0.375rem 0.75rem;
  background:#fff;
  display: flex;
  justify-content: space-between;
}
.header .mui-icon-help{
  color:#666;
  font-size:1.4rem;
  font-weight: bold;
}
a.mui-action-back{
  color: #222;
}
.mui-content{
  height:100%;
  background:#fff;
}

.mui-input-group:before{
  height:0;
  }

.mui-input-row label{
  /* width:auto; */
  /* text-align: left; */
  font-size: 0.9rem;
  font-weight:700;
}
.mui-input-row input{
  font-size: 0.9rem;
}
.mui-input-row label ~ input{
  float:right;
}
.mui-btn{
     width: 100%;
     height:2.3rem;
     background:#ccc;
     color:#fff;
     border-radius:2rem;
}
.mui-content-padded{
  margin-top:1.125rem;
}
.loginactive{
  background:linear-gradient(left,#ff5a00 33.33%,#ff7a00 33.33%,#ff5a00 33.33%) !important;
}
.telReg{
  display:flex;
  font-size: 0.8rem;
  text-align: left;
  justify-content: space-between;
  margin-top:1rem;
  padding: 0.375rem 0.75rem;
}
.telReg a{
  color:#999;
  font-size: 0.8rem;
  }
</style>
