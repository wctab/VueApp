  <template>
    <div>
      <header>
        <div class="header">
					<span>订单</span>
					<a href="javascript:;">
            <span>服务订单</span>
          </a>
				</div>
      </header>
      <div class="mui-content">
        <div id="slider" class="mui-slider">
          <div id="sliderSegmentedControl" class="mui-slider-indicator mui-segmented-control mui-segmented-control-inverted" :class="dshow==true?'dshow':''">
            <a class="mui-control-item mui-active" href="#all">
              全部
            </a>
            <a class="mui-control-item" href="#wait">
              代付款
            </a>
            <a class="mui-control-item" href="#pay">
              待消费
            </a>
            <a class="mui-control-item" href="#contact">
              待评价
            </a>
          </div>
          <div id="sliderProgressBar" class="mui-slider-progress-bar mui-col-xs-3 " :class="dshow==true?'dshow':''">
            <span class="ProgressBarSpan"></span>
          </div>
          <!-- header -->
          <div class="mui-slider-group">
            <div id="all" class="mui-slider-item mui-control-content mui-active">
              <div id="scroll1" class="mui-scroll-wrapper" :class="dno==true?'':'bg'">
                <div class="mui-scroll">
                  <div id="Login" :class="dno==true?'dno':''">
                    <img src="@/components/icon/loginlogo.png" alt="">
                    <p>当前操作需要您的登录</p>
                    <p>登录查看更多精彩内容</p>
                    <a class="loginNow" href="/login">
                      立即登录
                    </a>
                  </div>
                  <div class="dindan" :class="dshow==true?'dshow':''">
                    <div id="list" v-for='(item,index) of waitpay' :key='index'
                    class="mui-table-view mui-table-view-chevron">
                      <div class="dmtitle">
                        <p v-text='item.wname' class='wname'></p>
                        <p>已付款</p>
                      </div>
                      <div class="mui-table-view-cell mui-media">
                        <a class="mui-navigate-right">
                          <img :src="`${hurl}${item.wurl}`" class="mui-media-object mui-pull-left">
                          <div class="mui-media-body">
                            <span v-text="item.title" class='title'></span>
                            <p class="mui-ellipsis">
                              <span v-text='`共${item.count}件`'></span>
                              <span style="margin-left:0.5rem;" v-text='`${(item.price*item.count).toFixed(2)}元`'></span>
                            </p>
                            </div>
                        </a>
                      </div>
                      <div class="dm">
                        <img class="dmImg"  src="@/components/icon/eorder.png" alt="">
                        <span>饿了么</span>
                      </div>
			              </div>
                  </div>  
                  <div class="zhuanqu" :class="dshow==true||code==200?'dshow':''">
                    <div class="emty">
                     <img  src="@/components/icon/ordernone.png" alt="">
                     <p>还没有相关的订单哦</p>
                     <p>先去首页逛逛吧</p>
                     <a href="javascript:;">刷新</a>
                   </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="wait" class="mui-slider-item mui-control-content">
              <div id="scroll2" class="mui-scroll-wrapper">
                <div class="mui-scroll">
                     
                  <div class="zhuanqu" :class="dshow==true?'dshow':''">
                   <div class="emty">
                     <img  src="@/components/icon/ordernone.png" alt="">
                     <p>还没有相关的订单哦</p>
                     <p>先去首页逛逛吧</p>
                     <a href="javascript:;">刷新</a>
                   </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="pay" class="mui-slider-item mui-control-content">
              <div id="scroll3" class="mui-scroll-wrapper">
                <div class="mui-scroll">
                  <div class="zhuanqu" :class="dshow==true?'dshow':''">
                   <div class="emty">
                     <img  src="@/components/icon/ordernone.png" alt="">
                     <p>还没有相关的订单哦</p>
                     <p>先去首页逛逛吧</p>
                     <a href="javascript:;">刷新</a>
                   </div>
                  </div>
                </div>
              </div>
            </div>
            <div id="contact" class="mui-slider-item mui-control-content">
              <div id="scroll4" class="mui-scroll-wrapper">
                <div class="mui-scroll">
                  
                  <div class="zhuanqu" :class="dshow==true?'dshow':''">
                   <div class="emty">
                     <img  src="@/components/icon/ordernone.png" alt="">
                     <p>还没有相关的订单哦</p>
                     <p>先去首页逛逛吧</p>
                     <a href="javascript:;">刷新</a>
                   </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
          <!-- footer -->
        </div>
      </div>






      <Footer></Footer>
    </div>
  </template>      
<script>
import Footer from '@/components/footer.vue'
export default {
  data(){
    return{
      hurl:'http://localhost:4000/',
      dno:false,
      dshow:true,
      waitpay:[],
      code:302
    }
  },
  created(){
    this.loadWait();
    var uname = sessionStorage.getItem("uname");
		if(uname){
			this.dno=true;
			this.dshow = false;
		}else{
			this.dno=false;
			this.dshow =true;
		}
    this.$store.state.num=3
  },
  mounted(){
    mui.init({
				swipeBack: false
			});
			(function($) {
				$('.mui-scroll-wrapper').scroll({
					indicators: false //是否显示滚动条
				});
      })(mui);
      var uname = sessionStorage.getItem("uname");
		if(uname){
		 mui('.mui-slider').slider().stopped = false;
		}else{
			 mui('.mui-slider').slider().stopped = true;
		}
     
  },
  methods:{
    loadWait(){
      var url='http://localhost:4000/order/getpay';
      mui.ajax(url,{
        data:{},
        type:'get',
        dataType:"JSON",
        success:(result)=>{
          result = JSON.parse(result);
          if(result.code==200){
            this.code=result.code;
            this.waitpay=result.data;
          }
          console.log(this.waitpay)
        },
        error:()=>{
          mui.toast('加载订单出错');
        }
      })
    },
  },
  components:{
   Footer
  }
}
</script>
<style scoped>
.bg{
	background:#fff !important;
}
  header{
    width:100%;
    position: fixed;
    z-index:99;
		height:3.5rem;
    background:linear-gradient(left,#ff8500,#ff5a00);
  }
  .header{
    width:100%;
    position:relative;
    font-size:1rem;
    color:#fff;
	}
  .header>span{
    position: absolute;
    font-weight:700;
    left:11rem;
    top:1.5rem;
  }
  .header a{
     position: absolute;
     right:1rem;
     top:1.5rem;
  }
  .header a>span{
    font-size:0.8rem;
    font-weight:500;
    color:#fff;
  }
/* 滑动 */
  .mui-control-content {
				background-color: white;
				min-height:650px;
	}
  .mui-slider .mui-segmented-control.mui-segmented-control-inverted ~ .mui-slider-group .mui-slider-item{
    border:none;
  }
  .mui-icon-search{
		padding-right:1rem;
	}
  .mui-segmented-control.mui-segmented-control-inverted .mui-control-item.mui-active{
    color:#ff5a00;
  }
	#slider .mui-control-item{
		font-size:1rem;
		font-weight:bold;
	}
  #sliderSegmentedControl{
		position: fixed;
    /* background: #fff; */
		top:3.5rem;
  }
  #sliderSegmentedControl,#sliderProgressBar{
		position:fixed;
		top:3.5rem;
    z-index:99;
  }
	.ProgressBarSpan{
		display:inline-block;
		position:absolute;
		top:0;
		left:40%;
		width:0.8rem;
		height:0.15rem;
		background:#ff5a00;
	}
  .mui-segmented-control.mui-segmented-control-inverted ~ .mui-slider-progress-bar{
    background-color: transparent;
  }
  #sliderProgressBar{
    margin-top:2.35rem;
  }
  .mui-scroll-wrapper{
    background-color:#f5f5f5;
		top:7rem;
	}

  #Login{
	padding:0 0.85rem;
	text-align: center;
}
#Login p:nth-child(2){
	color:#000;
	font:1rem bold;
}
#Login p:nth-child(3){
	color:#999;
	font:0.8rem bold;
}
  #Login .loginNow{
	display:inline-block;
	color:#000;
	width:15rem;
	height:3rem;
	line-height:3rem;
	border-radius:2rem;
	font-size: 1.2rem;
	border:1px #ccc solid;
}

/* 滑动end */
.dindan{
  margin:0 1rem;
}
.dindan .mui-table-view-cell:after{
  height:0;
  background:#fff;
}
#list{
  margin-top:1rem;
  background: #fff;
  border-radius:0.5rem;
}
.dmtitle{
  display: flex;
  height:2.8rem;
  justify-content: space-between;
  align-items: center;

}
.dmtitle>p{
  margin-bottom: 0;
  font-size: 1.125rem;
  
}
.wname{
  width:10rem;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.dmtitle>p:first-child{
  margin-left:1.5rem;
  color:#333;
}
.title{
  display: inline-block;
  width:15rem !important;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.dmtitle>p:nth-child(2){
  margin-right: 1.5rem;
  color:#ff5a00;
}
.mui-navigate-right{
  padding-top:0 !important;
}

.mui-media-body{
  text-align: left;
  line-height:1.5rem;
}

.mui-navigate-right:after, .mui-push-right:after{
  content: ''
}




.dm{
  display: flex;
  align-items:center;
  height:2rem;
}
.dmImg{
  width:1.5rem !important;
  height:1.5rem;
  margin-left:1rem;
}
.dm span{
  margin-left:0.5rem;
  color:#b9b9b9;
}

.dno{
	display: none;
}
.dshow{
	display: none;
}

.emty img{
  padding-top:4rem;
  width:50% !important;
}
.emty p:nth-child(2){
  color:#000;
  font-size:1rem;
}

</style>
