  <template>
    <div class="index_mui">
			<header class="header" :class="show==true?'disShow':''">
					 <div class="d-fixd clearfix" :style="head">
							<div class="mui-input-row mui-input-search">
									<span class="mui-icon mui-icon-search"></span>
									<input @focus="search" type="search" class="mui-input-clear search_back" placeholder="棒约翰9.9元起">
							</div>
              <router-link to="#" class="address">
								<span class="mui-icon-extra mui-icon-extra-sweep"></span>
							</router-link>
							<router-link to="#" class="address">
								<span class="mui-icon-extra mui-icon-extra-topic"></span>
							</router-link>
							<router-link to="#" class="address chatbubble">
								<span class="mui-icon mui-icon-chatbubble"></span>
							</router-link>
						</div>
			</header>
			<div id="refreshContainer" class="mui-content mui-scroll-wrapper">
				<div class="mui-scroll">
					<header class="opa">
						<div :style="opacity">
							<div class="d-fixd clearfix">
								<router-link to="/location" class="address addredown">
								<span class="addDef">{{this.$store.state.location}}</span>
								<img class="down" src="@/components/icon/down.png" alt="">
							</router-link>
							<div class="mui-input-row mui-input-search">
									<span class="mui-icon mui-icon-search" @click="search"></span>
									<input type="search" class="mui-input-clear search_back" placeholder="棒约翰9.9元起" @focus='search'>
							</div>
							<router-link to="#" class="address">
								<span class="mui-icon-extra mui-icon-extra-topic"></span>
							</router-link>
							<router-link to="#" class="address chatbubble">
								<span class="mui-icon mui-icon-chatbubble"></span>
							</router-link>
							</div>
						</div>
						<nav class="hotSearch">
							<ul class="d-flex">
								<li>热搜：</li>
								<li>
									<router-link to="#" class="hot">
										<span class="zhekou">COFFEE5折起</span>
									</router-link>
								</li>
								<li>
									<router-link to="#" class="hot">
										<span class="zhekou">三川市集4.8折起</span>
									</router-link>
								</li>
								<li>
									<router-link to="#" class="hot">
										<span class="zhekou">Coco都可5折起</span>	
									</router-link>
								</li>
							</ul>
							<div class="hotSearch_elm">
								<router-link to="#" class="saosao">
									<p class="mui-icon-extra saosao mui-icon-extra-sweep"></p>
									<p class="saosao" style="margin-top:-0.2rem;">扫一扫</p>
								</router-link>
								<router-link class="xmj_router" to="#">
										<img class="elm" src="@/components/icon/ziti.png" alt="">
									<p class="saosao elmziti">到店自提</p>
									<i class="xmj"><span>享满减</span></i>
								</router-link>
								<router-link to="#">
									<p class="mui-icon-extra saosao mui-icon-extra-outline"></p>
									<p class="saosao">预定</p>
								</router-link>
								<router-link to="/hmjmf">
									<img class="elm elem" src="@/components/icon/elem.png" alt="">
									<p class="saosao elemwm">外卖</p>
								</router-link>
							</div>
						</nav>
					</header>
			<table></table>
			<div id="container">
					<Corouse class="Corouse"></Corouse>
					<tabNav></tabNav>	
					<div id="zhuanqu">
						<div class="gifts">
							<router-link to="#">
								<img src="tvImg/nonc.png" alt="">
							</router-link>
							<router-link to="#">
								<img src="tvImg/jfen.png" alt="">
							</router-link>
							<router-link to="#">
								<img src="tvImg/super.png" alt="">
							</router-link>
						</div>

						<div class="newPerson">
							<div class="newPerson_top">
								<router-link class="Top" to="#">
									<span>新人专区</span>
									<span>首单特惠</span>
									<span>低至五折</span>
								</router-link>
								<router-link class="more" to="#">更多&gt;</router-link>
							</div>
							<div class="newperson_price">
								<router-link to="#">
									<img class="newimg1" src="img/newperson/newP.png" alt="">
								</router-link>
								<router-link class="router" style="margin-left:0.5rem;" to="#">
									<img class="newimg2" src="img/newperson/yoko.png" alt="">		
									<p class="dname">YOKO(闻喜路店)</p>
									<p class="title">亚米巧克力</p>
									<span class="newprice">新人价：</span><span class="price">7.90元</span>
								</router-link>
								<router-link class="router" to="#">
									<img class="newimg3" src="img/newperson/qm.png" alt="">		
									<p class="dname">来伊份(闻喜路店)</p>
									<p class="title">金芒/青芒</p>
									<span class="newprice">新人价：</span><span class="price">6.90元</span>
								</router-link>
							</div>
						</div>
						<div class="qianggou">
							<div class="newPerson_top">
								<router-link class="Top" to="#">
									<span>超值抢购</span>
									<span class="hms">{{hours}}</span>:<span class="hms">{{minutes}}</span>:<span class="hms">{{seconds}}</span>
								</router-link>
								<router-link class="more" to="#">更多&gt;</router-link>
							</div>
							<div class="jgtimes">
								<router-link class="qgrouter" to="#">
									<img src="img/qainggou/coco.png" alt="">
									<p class="dname">CoCo都可</p>
									<p class="title">2份金吉柠檬(中)</p>
									<span class="price">12.00元</span><del style="bottom:-0.1rem;">24元</del>
								</router-link>
								<router-link class="qgrouter" to="#">
									<img src="img/qainggou/yezi.png" alt="">
									<p class="dname">鲜丰水果</p>
									<p class="title">泰国椰青1个</p>
									<span class="price">9.90元</span><del style="left:2.5rem;bottom:-0.2rem;">12元</del>
								</router-link>
								<router-link class="qgrouter" to="#">
									<img src="img/qainggou/tea.png" alt="">
									<p class="dname">人在茶在</p>
									<p class="title">布丁奶茶</p>
									<span class="price">7.98元</span><del style="left:2.5rem;bottom:-0.1rem;">12元</del>
								</router-link>
							</div>
						</div>
						<!--这里省略n++行  -->
						<div class="private">
							<div class="newPerson_top">
								<router-link class="Top" to="#">
									<span>为你定制</span>
									<span>美好的一天从人气早餐开始</span>
								</router-link>
							</div>
							<ul class="mui-table-view">
								<li class="mui-table-view-cell mui-media" v-for="item of 10" 
								:key="item">
									<router-link to="#">
										<img class="mui-media-object mui-pull-left" 
										src="img/private/dp1.jpg">
										<div class="mui-media-body">
												营养菜饭骨头汤{{item}}
											<p class='mui-ellipsis'>
												<img src="img/private/4_star.png" alt="">
												<span class="range">110m</span>
											</p>
										</div>
									</router-link>
								</li>   
							</ul>
						</div>
					<!-- 专区底 -->
					<p></p><p></p><p></p><p></p><p></p><p></p>
					</div>	
				</div>
			</div>
		</div>
			



      <Footer></Footer>
    </div>
  </template>  
<script>
import Footer from '@/components/footer.vue'
import Header from '@/components/header.vue'
import Corouse from '@/components/muiCorouse.vue'
import tabNav from '@/components/table-view.vue'
import { setTimeout, setInterval, clearInterval } from 'timers';
export default {
  data(){
    return{
			show:false,
			head:{
				"opacity":0
			},
			opacity:{
				"opacity":1,
			},
			hours:20,
			minutes:32,
			seconds:45
		}
	},
	created(){
		this.$store.state.num=1;

	},
	mounted(){
		setInterval(()=>{
			var day = new Date("2019/5/26");
			var now = new Date();
			var ms = day.getTime()-now.getTime();
			var m = Math.floor(ms/1000);
			var days = Math.floor(m/(24*60*60))
			var hours = m%(24*60*60);//剩余的天数 
					hours=Math.floor(hours/3600);//剩余小时
			var minutes = Math.floor((m%3600)/60);
			var seconds = m%60;
			(hours<10)&&(hours = "0"+hours);
			(minutes<10)&&(minutes = "0"+minutes);
			(seconds<10)&&(seconds = "0"+seconds);
			this.hours = hours;
			this.minutes = minutes;
			this.seconds = seconds;

		},1000)
	//下拉刷新
	  mui.init({ 
			pullRefresh : {
					container:"#refreshContainer",//下拉刷新容器标识，querySelector能定位的css选择器均可，比如：id、.class等
					down : {
						style:'circle',//必选，下拉刷新样式，目前支持原生5+ ‘circle’ 样式
						color:'#2BD009', //可选，默认“#2BD009” 下拉刷新控件颜色
						// height:'50px',//可选,默认50px.下拉刷新控件的高度,
					//	range:'100px', //可选 默认100px,控件可下拉拖拽的范围
					 	contentdown : "下拉可以刷新",
						contentover : "释放立即刷新",
						contentrefresh : "正在刷新...",
						offset:'0px', //可选 默认0px,下拉刷新控件的起始位置
						auto: false,//可选,默认false.首次加载自动上拉刷新一次
						indicators: false,
						callback :this.pulldownRefresh //必选，刷新函数，根据具体业务来编写，比如通过ajax从服务器获取新数据；
					},
				　　up:{
				　　　　contentrefresh: '正在加载...',
				　　　　contentnomore:'没有更多数据了',
				　　　　callback:this.pulluploading //上拉加载下一页
				　　}
				}
			});
			var scroll = mui('.mui-scroll-wrapper').scroll();
			document.querySelector('.mui-scroll-wrapper').addEventListener('scroll',(e) =>{
				// console.log(scroll.y);
				var y=scroll.y
			// 　　if(y>-10){
			// 			this.show =false; 
			// 			this.head['opacity']=0
			// 			this.opacity["opacity"] = 1;
			// 		}
					for(var o=1;o<3;o++){
							if(y>-3.33*o){
								this.show =false; 
								this.head['opacity']=0
								this.opacity["opacity"] = 0.3*o;
							}
							if(y>=0||this.opacity["opacity"] ==0.9){
								this.opacity["opacity"] =1;
							}
					}
					for(var i=1;i<6;i++){
						if(y<-10*i){
							this.show =true; 
							this.opacity["opacity"] =0;
							this.head['opacity']=0.2*i
						}
					}
			})
			
		
	},
	methods:{
		pulldownRefresh(){
			setTimeout(function() {
				mui('#refreshContainer').pullRefresh().endPulldownToRefresh();
			},1500)
		},
		pulluploading(){
			setTimeout(function(){
				mui('#refreshContainer').pullRefresh().endPullupToRefresh(true);
			},1500)
		},
		search(){
				 this.$router.push("/search")
		}
	},
  components:{
	 Footer,
	 Header,
	 Corouse,
	 tabNav,
	}
	
}
</script>
<style scoped>
.disShow{
	z-index:1000;
}
.header .mui-icon-extra-sweep{
  font-size:1.2rem;
}
.index_mui{
	padding:0;
	margin:0;
	background-color:#fff;
}
.index_mui header{
	position:fixed;
	width:100%;
	background:linear-gradient(left,#ff8500,#ff5a00);
}
.index_mui header::before{
	content:"";
	display:table;
}
.d-fixd{
	display:flex;
	flex-wrap:nowrap;
	width:100%;
	/* height:4rem; */
	/* line-height:4rem; */
	justify-content:space-around;
	align-items:flex-end;
	padding-bottom:0.8rem;
	/* background:linear-gradient(left,#ff8500,#ff5a00); */
}
.opa{
	z-index:999;
	background:linear-gradient(left,#ff8500,#ff5a00);
}
.address{
	color:#fff;
}
.addDef{
	font-size:1.2rem;
	font-weight:300;
}
.address .down{
	width:1rem;
}

.mue-active{
    color:#ff5a00;
	}
.mui-icon-search{
	font-size:1rem;
	color:#ff5a00;
	}
.mui-input-search{
		position:relative;
		top:1rem;
	}
.mui-icon-search{
	position:absolute;
	top:15%;
	left:5%;
}
.mui-input-row .search_back{
	background-color:#fff;
	height:1.7rem;
	border-radius:1.7rem;
	font-size:0.18rem;
	padding-left:1.8rem;
}
header .mui-icon-extra-topic{
		font-size:1.1rem;
}
header .mui-icon-chatbubble{
	font-size:1.6rem;
}
/* .hotSearch{
	position:relative;
} */
.d-flex{
	display:flex;
	flex-wrap:nowrap;
	justify-content:space-around;
}
.hotSearch>ul>li:first-child{
	font-size:0.3rem;
	color:#fff;
	font-weight:100;
}
.hot{
	display:inline-block;
	/* width:6rem; */
	height:1.18rem;
	border-radius:1.7rem;
	font-size:0.18rem;
	background-color:#ff9333;
}
.hot>span{
	font-size:0.2rem;
	color:#fff;
	font-weight:100;
}
.zhekou{
	padding:0 0.18rem;
}
.xmj_router{
	position:relative;
}
.xmj{
	position:absolute;
	top:-0.5rem;
	right:-1.6rem;
	width:2.8rem;
	border-radius:2.8rem;
	background: #fff;
}
.xmj>span{
	color:#ff5a00;
	font-size:0.5rem;
}
.hotSearch_elm{
	margin-top:1.6rem;
	display: flex;
	justify-content: space-around;
}
.hotSearch_elm .mui-icon-extra-sweep{
	padding-top:0.5rem;
	font-size:1.8rem !important; 
}
.hotSearch_elm .mui-icon-extra{
	font-size:2rem;
}
.elmziti{
	margin-top:-0.4rem;
}
.saosao{
	color:#fff;
}
.elm{
	width:1.7rem;
	margin-bottom:0.6rem;
}
.elem{
	padding-top:0.2rem;
	width:1.6rem;
}
.elemwm{
	margin-top:-0.2rem;
}
header::after{
	content:"";
	display:table;
}
#container{
	padding-top:11.5rem;/*11*/
	background-color:#fff;
}
#zhuanqu{
	padding:0 0.85rem;
}
.gifts{
	display:flex;
	justify-content: space-between;
	margin-top:1.2rem;
}
.gifts img{
	width:100%;
}
.newPerson,.qianggou,.private{
	margin-top:1.5rem;
}
.newPerson_top{
	position: relative;
	text-align:left;
}
.Top{
	color: #000;
	font-size:0.9rem;
	font-weight:700;
	margin-left:0.18rem;
}
.newPerson_top span:nth-child(2),
.newPerson_top span:nth-child(3){
	color:#999;
	margin-left:0.4rem;
	font-size:0.7rem;
}
.more{
	position:absolute;
	color:#999;
	font-size:0.8rem;
	font-weight:bold;
	right:0.4rem;
}
.newperson_price{
	
	margin-top:0.6rem;
	display: flex;
	justify-content: space-between;
	text-align:left;
}
.newperson_price .router{
	position:relative;
}
.newimg1{
	width:100%;
}
.newimg2,.newimg3{
	width:95%;
}
.dname{
	/* margin-top:0.3rem; */
	font-size:0.6rem;
	font-weight:bold;
	color:#222;
}
.title{
	margin-top:-0.7rem;
	font-size:0.6rem;
	color:#222;
}
.newprice{
	position:absolute;
	bottom:0;
	color:#f00;
	font-size:0.6rem;
}
.price{
	position:absolute;
	bottom:0;
	left:2.8rem;
	color:#f00;
	font-size:0.6rem;
	font-weight:bold;
}
.jgtimes{
	display:flex;
}
.jgtimes img{
	width:100%;
}
.hms{
	display: inline-block;
	width:0.9rem;
	height:0.9rem;
	position:relative;
	bottom:0.118rem;
	text-align: center;
	line-height: 0.9rem;
	background:#000;
	color:#999;
	font-size:0.6rem;
}
.qgrouter{
	position:relative;
	margin-top:0.8rem;
	text-align:left;
}
.qgrouter .title{
	padding-top:0.2rem;
	margin-bottom:0;
}
.qgrouter .price{
	left:0;
}
.qgrouter del{
	position:relative;
	left:2.8rem;
	bottom:0;
	color:#999;
	font-size:0.6rem;
}
.private .newPerson_top{
	margin-bottom:1.2rem;
}
.private img.mui-pull-left{
	width:100%;
}
.private .mui-table-view .mui-media-body{
	text-align:left;
	font-size: 0.85rem;
	font-weight:bold;
	color:#000;
}
.private .mui-media-body .mui-ellipsis {
	position: relative;
}
.private .mui-ellipsis img{
	width:25%;
}
.private .mui-ellipsis span:nth-child(2){
	position: absolute;
	right:0.6rem;
}
</style>
