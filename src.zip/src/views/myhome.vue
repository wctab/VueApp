  <template>
    <div class="container">
      <header>
        <div>
					<router-link to="/setup" class="settings">
							<span class="mui-icon mui-icon-gear" :class="dshow==true?'dshow':''"></span>
					</router-link>
					<router-link to="#" class="sculplink">
							<img class="sculpture" :class="dshow==true?'dshow':''" src="img/dog.jpg" alt="">
							<span class="uname" :class="dshow==true?'dshow':''">用户名</span>
					</router-link>
					<div style="position:relative">
						<span style="position:absolute;left:50%;color:#fff; top:-2rem;" 
            :class="dno==true?'dno':''">我的</span>
						<span style="position:absolute;right:5%;color:#fff;bottom:0.95rem;" class="mui-icon mui-icon-gear" 
            :class="dno==true?'dno':''" @click="info"></span>
					</div>
				</div>
				<nav class="hotSearch" :class="dshow==true?'dshow':''">
					<div class="hotSearch_elm">
						<router-link to="#">
							<img style="" src="img/home/jb.jpg">
							<p class="saosao" style="margin-left:-0.4rem;">卷包</p>
						</router-link>
						<router-link to="#">
							<img src="img/home/kb.jpg">
							<p class="saosao" style="margin-left:-0.4rem;">卡包</p>
						</router-link>
						<router-link to="#">
							<img src="img/home/sc.jpg">
							<p class="saosao">收藏</p>
						</router-link>
						<router-link to="#">
							<img style="margin-top:-0.5rem;" src="img/home/pj.jpg">
							<p class="saosao" style="margin-left:-0.8rem;">评价</p>
						</router-link>
					</div>
			  </nav>
        <div id="Login" :class="dno==true?'dno':''">
          <img src="@/components/icon/loginlogo.png" alt="">
          <p>当前操作需要您的登录</p>
          <p>登录查看更多精彩内容</p>
          <router-link class="loginNow" to="/login">
                立即登录
          </router-link>
        </div>
			</header>
        <!-- content -->
      <table></table>
      <div class='vip' :class="dshow==true?'dshow':''">
        <div class="vipContent">
					<div class="superVip">
						<router-link class="superVipa" to="#">
							<div>
								<p>口碑超级会员</p>
								<p>每月5次8.8折,立即购买</p>
							</div>
							<img src="img/home/zs8.jpg" alt="">
						</router-link>
					</div>
					<div class="kbnonc">
						<router-link class="kbnonca" to="#">
							<div>
								<p>口碑农场 0元水果免费吃</p>
								<p>种啥吃啥,为自己加餐</p>
							</div>
							<img src="img/home/sgs.jpg" alt="">
						</router-link>
					</div>
					<div class="mygj">
						<p>我的工具</p>
						<div class="gjlist">
							<router-link style="margin-top:1.25rem;" class="gjlista" to="#">
								<img src="img/home/kblm.jpg" alt="">
								<p>口碑联名卡</p>
							</router-link>
							<router-link class="gjlista" to="#">
								<img src="img/home/yhk.jpg" alt="">
								<p>银行卡特惠</p>
							</router-link>
							<router-link class="gjlista" to="#">
								<img src="img/home/wdjf.jpg" alt="">
								<p>我的积分</p>
							</router-link>
							<router-link style="margin-top:1.25rem;" class="gjlista" to="#">
								<img src="img/home/tmyh.jpg" alt="">
								<p>天猫优惠专区</p>
							</router-link>
							<router-link class="gjlista" to="#">
								<img src="img/home/zxh.jpg" alt="">
								<p>真心话大冒险</p>
							</router-link>
							<router-link style="margin-top:1.45rem;" class="gjlista" to="#">
								<img src="img/home/yq.jpg" alt="">
								<p>邀请赚现金</p>
							</router-link>
							<router-link style="margin-top:1.35rem;" class="gjlista" to="#">
								<img src="img/home/sjrz.jpg" alt="">
								<p>商家入驻</p>
							</router-link>
							<router-link class="gjlista" to="#">
								<img src="img/home/gy.jpg" alt="">
								<p>3小时公益</p>
							</router-link>
							<router-link style="margin-top:1.25rem;" class="gjlista" to="#">
								<img src="img/home/help.jpg" alt="">
								<p>帮助与反馈</p>
							</router-link>
							<router-link class="gjlista" to="#">
								<img src="img/home/rule.jpg" alt="">
								<p>协议规则</p>
							</router-link>
						</div>
					</div>
				</div>
      </div>


      <Footer></Footer>
    </div>
  </template>      
<script>
import Footer from '@/components/footer.vue'
export default {
  data(){
    return{
      dno:false,
			dshow:true,
    }
  },
  created(){
    var uname = sessionStorage.getItem("uname");
		if(uname){
			this.dno=true;
			this.dshow = false;
		}else{
			this.dno=false;
			this.dshow =true;
		}
    this.$store.state.num=4
	},
	methods:{
		info(){
			mui.toast("请先登录!")
		}
	},
  components:{
   Footer
  }
}
</script>
<style scoped>
.container{
	background: #fff;
}
header{
	position: fixed;
  width:100%;
}
header::before{
  content:'';
  display: table;
}
.settings{
  position:absolute;
  z-index: 999;
  color:#fff;
  right:5%;
  top:8%;
}
.sculplink{
  background:linear-gradient(left,#ff8401,#ff5500);
  display:block;
  padding-top:1.5rem;
  position: relative;
  text-align:left;
  height:4.5rem;
  line-height:3rem;
}
header .sculpture{
  display:inline-block;
  width:3rem;
  height:3rem;
  border-radius:50%;
  margin-left:1.2rem;
}
header .uname{
	position: relative;
	display: inline-block;
	top:-1rem;
	color:#fff;
  margin-left:0.8rem;
}
.address{
	color:#fff;
}
.mue-active{
    color:#ff5500;
	}
.mui-input-search{
		position:relative;
	}

.mui-icon-extra-topic{
		font-size:0.98rem;
}
.mui-icon-chatbubble{
	font-size:1.6rem;
}
.hotSearch{
	margin-top:-0.1rem;
  background:linear-gradient(left,#ff8401,#ff5500);
}
.hotSearch_elm{
	padding-top:1.6rem;
  padding-bottom:2rem;
	display: flex;
	justify-content: space-around;
}
.hotSearch_elm img{
	width:40%;
}
.hotSearch_elm .mui-icon-extra{
	font-size:2rem;
}
.saosao{
	color:#fff;
	font-size: 0.8rem;
	font-weight:500;
}

#Login{
	min-height:568rem;
	background:#fff;
	text-align: center;
}
#Login img{
	margin-top:3rem;
  width:90%;
}
#Login p:nth-child(2){
	color:#000;
	font:1rem bold;
}
#Login p:nth-child(3){
	color:#999;
	font:0.8rem bold;
}
  #Login .loginNow{
	display:inline-block;
	color:#000;
	width:15rem;
	height:3rem;
	line-height:3rem;
	border-radius:2rem;
	font-size: 1.2rem;
	border:1px #ccc solid;
}
.dno{
	display: none !important;
}
.dshow{
	display: none !important;
}

.vip{
  position:relative;
	width:92%;
	left:4%;
	top:-1.3rem;
	border-radius:0.5rem 0.5rem 0 0;
	background:#fff;
  margin-top:12.125rem;
}
.vipContent{
	width:92%;
	margin-left:4%;
}
.superVip{
	padding-top:1rem;
}
.superVipa{
	display:flex;
	text-align:left;
}
.superVipa p:first-child{
	color:#d59c65;
	font-size: 1.075rem;
	font-weight: bold;
}
.vipContent p{
	margin:0;
	}
.superVipa p:nth-child(2){
	font-size: 0.8rem;
	margin-top:0.2rem;
}
.superVip img{
	margin-top:-0.4rem;
	width:25%;
	height:25%;
	margin-left:5.5rem;
}
.kbnonc{
	padding-top:2rem;
}
.kbnonca{
	display:flex;
	text-align:left;
	justify-content: space-between;
}
.kbnonca img{
	width:50%;
	height:5%;
}
.kbnonca p:first-child{
	color:#222;
	font-size: 0.9rem;
	font-weight: bold;
}
.kbnonca p:nth-child(2){
	font-size: 0.8rem;
	margin-top:0.2rem;
}
.mygj{
	padding-top:1.2rem;
	position: relative;
}
.mygj>p{
	color:#222;
	position: absolute;
	font-size:1.075rem;
	font-weight: bold;
}
.gjlist{
	margin-top:1rem;
	display: flex;
	width:100%;
	flex-wrap:wrap;
	padding-bottom:2rem;
}
.gjlista{
	margin-top:1rem;
	width:25%;
}
.gjlista img{
	width:35%;
}
.gjlista p{
	font-size:0.6rem;
	color:#555;
}
</style>
