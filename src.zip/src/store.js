import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    num:1,
    location:"广州",
    price:"未选购商品",
    all:"￥20起送",
    cartCount:sessionStorage.getItem("cartCount")||0,//全局共享
    total:"",
    selProducts:[],
    cartProducts:[]
  },
  mutations: {
    increment(state){ //增加购物车数量 this.$store.commit("increment")
      state.cartCount++;
      sessionStorage.setItem("carCount",state.cartCount)
    },
    sub(state){
      state.cartCount--;
      if(state.cartCount==0){
        state.cartCount=0;
      }
    }
  },
  getters:{ //获取购物车数据函数 this.$store.getter.getCartCount
    /*getcartCount(state){
      return state.cartCount;
    },
    getTotal(state){
      var all = count*price 
      state.total+=all;
    }*/
  },
  actions: {

  }
})
