import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import Index from './views/index'
import live from './views/live'
import order from './views/order'
import myhome from './views/myhome'
import header from './components/header'
import muiCorouse from './components/muiCorouse'
import recom from './views/recommend'
import register from './views/register'
import login from './views/login'
import setup from './components/setup'
import location from './views/location'
import hmjmf from "./views/hmjmf"
import hmf from './components/hmfooter'
import search from "./views/search"
import VueRouter from 'vue-router';

Vue.use(Router);

export default new Router({
  mode: 'history', 
  routes: [
    { path: '/',component: Index},
    { path: '/index', name: 'index',component: Index},
    { path: '/live',component: live},
    { path: '/order',component: order},
    { path: '/myhome',component:myhome,},
    { path: '/header',component:header},
    { path: '/Cor',component:muiCorouse},
    { path: '/recom',component:recom},
    { path: '/register',component:register},
    { path: '/login',component:login},
    { path: '/setup',component:setup},
    { path: '/location',component:location},
    { path: '/hmjmf',component:hmjmf,beforeEnter:(to,from,next)=>{
      var uname = sessionStorage.getItem("uname");
      if(uname){
        next();
      }else{
        next("/login");
      }
    }},
    { path: '/hmf',component:hmf},
    { path: '/home',component:Home},
    { path: '/search',component:search},

  ]
})
