import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
// 导入 MUI 的样式表， 和 Bootstrap 用法没有差别

import './lib/mui/css/mui.css'
// 导入 MUI 的样式表，扩展图标样式，购物车图标

// 还需要加载图标字体文件
import './lib/mui/css/icons-extra.css'
Vue.config.productionTip = false

Vue.directive("focus",{
  inserted:function(el){
    el.focus();
  }
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
