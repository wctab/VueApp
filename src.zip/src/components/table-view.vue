<template>
  <div id="Gallery" class="mui-slider" style="margin-top: 15px;">  
      <div class="mui-slider-group">
        <div class="mui-slider-item">
          <ul class="mui-table-view mui-grid-view mui-grid-9 Grid">
		            <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3">
                  <router-link to="#">
		                    <img src="tvImg/ms.png">
		                    <div class="mui-media-body">美食</div>
                    </router-link>
                </li>
		            <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><router-link to="#">
		                    <img style="margin-top:-0.05rem;" src="tvImg/play.png">
		                    <div class="mui-media-body">休闲娱乐</div></router-link></li>
                <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                   <img  src="tvImg/tao.png">
		                    <div style="padding-top:0.1rem;" class="mui-media-body">淘票票电影</div></a></li>
		            <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                    <img style="margin-top:-0.2rem;" src="tvImg/chao.png">
		                    <div style="margin-top:0.15rem;" class="mui-media-body">超市</div></a></li>
                <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                    <img src="tvImg/ktv.png">
		                    <div class="mui-media-body">KTV</div></a></li>
                <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                    <img style="margin-top:-0.5rem;" src="tvImg/jd.png">
		                    <div style="margin-top:0.1rem;" class="mui-media-body">机票/火车票</div></a></li>
                <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                    <img style="margin-top:-0.2rem;" src="tvImg/jp.png">
		                    <div style="margin-top:0.35rem;" class="mui-media-body">酒店预订</div></a></li>
                <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                    <img style="margin-top:-0.5rem;" src="tvImg/all.png">
		                    <div style="margin-top:0.1rem;" class="mui-media-body">全部</div></a></li> 
          </ul>
        </div>
        <div class="mui-slider-item">
          <ul class="mui-table-view mui-grid-view mui-grid-9 Grid">
                <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                    <img style="margin-top:-0.2rem;" src="tvImg/chao.png">
		                    <div style="margin-top:0.15rem;" class="mui-media-body">超市</div></a></li>
		            <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3">
                  <router-link to="/login">
		                    <img src="tvImg/ms.png">
		                    <div class="mui-media-body">美食</div>
                    </router-link>
                </li>
		            <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><router-link to="/GoodList">
		                    <img style="margin-top:-0.05rem;" src="tvImg/play.png">
		                    <div class="mui-media-body">休闲娱乐</div></router-link></li>
                <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                   <img  src="tvImg/tao.png">
		                    <div style="padding-top:0.1rem;" class="mui-media-body">淘票票电影</div></a></li>
                <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                    <img style="margin-top:-0.5rem;" src="tvImg/all.png">
		                    <div style="margin-top:0.1rem;" class="mui-media-body">全部</div></a></li>        
                <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                    <img src="tvImg/ktv.png">
		                    <div class="mui-media-body">KTV</div></a></li>
                <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                    <img style="margin-top:-0.5rem;" src="tvImg/jd.png">
		                    <div style="margin-top:0.1rem;" class="mui-media-body">机票/火车票</div></a></li>
                <li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3"><a href="#">
		                    <img style="margin-top:-0.2rem;" src="tvImg/jp.png">
		                    <div style="margin-top:0.35rem;" class="mui-media-body">酒店预订</div></a></li>
          </ul>
        </div>
      </div>
      <div class="mui-slider-indicator">  
        <div class="mui-indicator mui-active"></div>  
        <div class="mui-indicator"></div>
      </div>  
  </div>
</template>
<script>
export default {
  data(){
    return{}
  }
}
</script>
<style scoped>
.mui-grid-view.mui-grid-9{
  border:none;
  background-color:#fff;
}
.mui-grid-view.mui-grid-9 li img{
  width:50%;
}
.mui-table-view.mui-grid-view .mui-table-view-cell .mui-media-body{
  font-size:0.625rem;
}
.mui-grid-view.mui-grid-9 .mui-table-view-cell{
  border:none;
}
.mui-grid-view.mui-grid-9 .mui-table-view-cell{
  padding-top:0;
  padding-bottom:0;
}
.mui-slider-indicator .mui-indicator{
    width:1.18rem;
    height:0.18rem;
    border-radius:20%;
    margin:0;
    background:#ddd;
    box-shadow:0 0 0 0 ;
  }
  .mui-slider-indicator{
    bottom:-0.27rem;
  }
  .mui-col-xs-3 {
    width:25%;
  }
.mui-slider-indicator .mui-active.mui-indicator {
    background:#ff5500 !important;
  }
.mui-media-body{
  color:#000;
}
</style>
