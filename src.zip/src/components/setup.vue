<template>
  <div>
    <header class="header">
        <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>
        <span>设置</span>
    </header>
    <ul class="setupul mui-table-view mui-table-view-chevron mui-table-view-inverted">
					<li class="mui-table-view-cell">
						<a class="mui-navigate-right">
							消息提醒设置
						</a>
					</li>
					<li class="mui-table-view-cell">
						<a class="mui-navigate-right">
							指纹/面容支付
						</a>
					</li>
					<li class="mui-table-view-cell">
						<a class="mui-navigate-right">
							权限设置
						</a>
					</li>
					<li class="mui-table-view-cell">
						<a class="mui-navigate-right">
							个性化推荐设置
						</a>
					</li>
					<li class="mui-table-view-cell">
						<a class="mui-navigate-right">
							清理缓存
						</a>
					</li>
					<li class="mui-table-view-cell">
						<a class="mui-navigate-right">
							关于口碑 7.0.62
						</a>
					</li>
				</ul>
        <div class="quit" @click="quit">
          <span>退出登录</span>
        </div>
  </div>
</template>
<script>
export default {
  data(){
    return{}
  },
  methods:{
    quit(){
      this.$router.push("/index")
      sessionStorage.clear();
    }
  }
}
</script>
<style scoped>
.header{
  position: relative;
  background:#fff;
  height:3rem;
  line-height:3rem;
}
.header .mui-icon{
  padding-left:0.5rem;
  line-height:3rem;
  color:#222;
}
.header>span{
  position: absolute;
  left:2.5rem;
  font-size:1.125rem;
}
.setupul{
  margin-top:1rem;
}
.mui-table-view-inverted:before{
  background:transparent;
}
.mui-table-view-inverted .mui-table-view-cell:after{
  background-color:transparent;
}
.mui-table-view-inverted:after{
   background-color:transparent;
}
.mui-table-view-chevron .mui-table-view-cell{
  padding-right:0;
}
.mui-table-view-cell{
  width:100%;
  text-align: left;
  background: #fff;
  color:#222;
  font-size:0.9rem;
}
.mui-navigate-right:after, .mui-push-left:after, .mui-push-right:after{
  color: #222;
  font-size: 1.2rem;
}
.mui-table-view-chevron .mui-table-view-cell > a:not(.mui-btn){
  margin-right:0;
}
.quit{
  display: inline-block;
  margin-top:2rem;
  background: #fff;
  width:100%;
  height:3rem;
  line-height:3rem;
  color:#ff5a00;
}
</style>
