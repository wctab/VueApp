<template>
  <header>
					 <div class="d-fixd clearfix">
							<div class="mui-input-row mui-input-search">
									<span class="mui-icon mui-icon-search"></span>
									<input type="search" class="mui-input-clear search_back" placeholder="棒约翰9.9元起">
							</div>
              <router-link to="#" class="address">
								<span class="mui-icon-extra mui-icon-extra-sweep"></span>
							</router-link>
							<router-link to="#" class="address">
								<span class="mui-icon-extra mui-icon-extra-topic"></span>
							</router-link>
							<router-link to="#" class="address chatbubble">
								<span class="mui-icon mui-icon-chatbubble"></span>
							</router-link>
						</div>
	</header>
</template>
<script>
export default {
  data(){
    return{}
  }
}
</script>
<style scoped>
  .index_mui{
	padding:0;
	margin:0;
}
.index_mui header{
	z-index:999;
	position:fixed;
	width:100%;
	background:linear-gradient(left,#ff8401,#ff5500);
}
.index_mui header::before{
	content:"";
	display:table;
}
.d-fixd{
	display:flex;
	flex-wrap:nowrap;
	width:100%;
	/* height:4rem; */
	/* line-height:4rem; */
	justify-content:space-around;
	align-items:flex-end;
	padding-bottom:0.8rem;
	background:linear-gradient(left,#ff8401,#ff5500);
}
.address{
	color:#fff;
}
.addDef{
	font-size:1.2rem;
	font-weight:300;
}
.address .down{
	width:1rem;
}
.mue-active{
    color:#ff5500;
	}
.mui-icon-search{
	font-size:1rem;
	color:#ff5500;
	}
.mui-input-search{
		position:relative;
		top:1rem;
	}
.mui-icon-search{
	position:absolute;
	top:15%;
	left:5%;
}
.mui-input-row .search_back{
	background-color:#fff;
	height:1.7rem;
	border-radius:1.7rem;
  width:15rem;
	font-size:0.18rem;
	padding-left:1.8rem;
}
header .mui-icon-extra-sweep{
  font-size:1.2rem;
}
header .mui-icon-extra-topic{
		font-size:1.1rem;
}
header .mui-icon-chatbubble{
	font-size:1.6rem;
}
</style>