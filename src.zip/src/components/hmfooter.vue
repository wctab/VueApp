<template>
  <div>
    <div id="popover" class="mui-popover myjmf">
        <p class="lj">已减0元，再买19.5元减27元</p>
        <div class="clear">
          <p>已选商品</p>
          <div @click="clearAll">
            <span class="mui-icon mui-icon-trash"></span><span>清空</span>
          </div>
        </div>
        <div id="cartContent">
          <div class="mui-scroll-wrapper">
          <div class="mui-scroll">
            <ul class="mui-table-view">
              <li id="cart" class="mui-table-view-cell" 
              v-for="(item,i) of cart" :key="i" 
              :class="cartcount==0?'dis':''">
                <div id="contentDes">
                  <p v-text="item.title"></p>
                  <p v-text="item.title"></p>
                </div>
                <div class="mui-numbox">
                    <span class="price" v-text="item.price"></span>
                    <button class="mui-btn mui-btn-numbox-minus" 
                    type="button" @click="reduce(item.hid)">
                      <span>-</span>
                    </button>
                    <input class="mui-input-numbox" type="number" 
                    v-model="item.count" 
                        />
                    <button class="mui-btn mui-btn-numbox-plus" 
                      type="button" @click="add(item.hid)">
                      <span>+</span>
                    </button>
                  </div>
              </li>
            </ul>
          </div>
        </div>
        </div>
    </div>
    <nav class="mui-bar mui-bar-tab ">
            <div class="h">
              <div class="cart" @click="toggle">
                <div class="" :class="cartcount!=0?'cactive':''">
                    <span class="mui-icon mui-icon-extra mui-icon-extra-cart" 
                    :class="0==0?'mcactive':''">
                    <span class="mui-badge" :class="cartcount==0?'dis':''">
                      {{this.$store.state.cartCount}}
                    </span>
                    </span>
                </div>
              </div>
              <div class="price">
                  <p 
                  :class="cartcount==0?'':'cartprice'" v-text="`${cartcount==0?this.$store.state.price:'￥'+this.$store.state.total}`"></p>
                  <p>另需配送费1.3元</p>
              </div>
            </div>
            <div id="openPopover"></div>
            <div class="qs" :class="this.$store.state.total>=20?'qactive':''" 
              @click='pay'>
               <p>{{this.$store.state.all}}</p>
            </div>
  </nav>
  </div>
</template>
<script>
export default {
  data(){
    return{
      value:1,
      cartcount:0,
      cart:[]
    }
  },
  mounted(){
  },
  updated() {
    this.cartcount = this.$store.state.cartCount;
    console.log("数量:"+this.cartcount);

    if(this.cartcount>0){
        if(this.$store.state.total>=20){
          this.$store.state.all="去结算"
        }else{
          this.gre =false;
          var s = 20-this.$store.state.total;
          this.$store.state.all="还剩"+(s.toFixed(2))+"起送"
        }
      }else{
          this.$store.state.all="￥20起送"
        };
        this.cart = this.$store.state.cartProducts;
        console.log("购物车：",this.cart)
  },
  methods:{
    pay(){
      if(this.$store.state.total>=20){
        var order = this.$store.state.cartProducts;
        console.log(order);
        mui.confirm('是否支付，确认？',(e)=>{
          if(e.index==1){
            mui.ajax('http://localhost:4000/order/pay',{
              data:{
                order:order
              },
              type:'get',
              dataType:'json',
              success:(result)=>{
                if(result.code==200){
                  console.log(result.msg);
                  this. clearAll();
                  mui.toast('您有一个订单生成，快去订单页查看吧');
                }
              },
              error:()=>{console.log("fail");}
            })
          }else{
            console.log('nono')
          }
        })
      }
    },
    toggle(){
      mui('.mui-popover').popover('toggle',document.getElementById("openPopover"));
    },
    reduce(hid){
      console.log(hid);
      for(var i=0;i<this.cart.length;i++){
        if(hid==this.cart[i].hid){
          
          if(this.cart[i].count==0){
            this.cart[i].count=0
          }else{
            this.cart[i].count--
            this.$store.commit("sub")
          }
        }
        this.$store.state.cartProducts = this.cart
      }
    },
    add(hid){
      console.log(hid);
      for(var i=0;i<this.cart.length;i++){
        if(hid==this.cart[i].hid){
          this.cart[i].count++
          this.$store.commit("increment")
        }
        this.$store.state.cartProducts = this.cart
      }
    },
    clearAll(){
      for(var i=0;i<this.cart.length;i++){
          this.cart[i].count=0
        }
        this.$store.state.cartCount=0;
        this.$store.state.cartProducts = this.cart
    }
  },
  watch:{
   
  }
}
</script>
<style scoped>
  #popover .lj{
    font-size: 0.6rem;
    height:1.5rem;
    line-height:1.5rem;
    color:#333;
    background:#fffbd8;
  }
  #popover .clear{
    position: relative;
    top:-0.5rem;
    width:100%;
    height:3rem;
    line-height:3rem;
    background: #ebeff2;
  }
  #popover .clear>p{
    margin-bottom:0;
    position:absolute;
    left:0.8rem;
    font-size: 1rem;
    letter-spacing:0.2rem;
    color:#666;
  }
  #popover .clear>div{
     position:absolute;
     right:0.8rem;
  }
  #popover .clear>div{
    font-size:0.6rem;
    color:#666;
  }
  #popover .clear .mui-icon-trash{
    font-size: 1.2rem;
    color:#666;
  }
  ul.mui-table-view{
    border-radius:0;
  }
  #cart{
    padding:0 0.8rem;
    border-radius:0;
    width: 100%;
    height:5rem;
    background:#fff;
  }
  #contentDes{
    width:50%;
    height:5rem;
    padding-left:0.8rem;
    text-align: left;
  }
  #contentDes>p:nth-child(1){
    margin-top:0.5rem;
    color:#000;
    width:10rem;
    font-size:0.98rem;
    letter-spacing: 0.125rem;
    white-space:nowrap;
    overflow:hidden;
    color:#222;
    text-overflow:ellipsis;
  }
  #contentDes>p:nth-child(2){
    color:#999;
    width:10rem;
    white-space:wrap;
    font-size:0.6rem;
  }

  #cartContent .mui-scroll-wrapper{
    top:4rem;
    padding-bottom:5rem;
    border-radius:0;
  }
  #cart.mui-table-view-cell{
    height:5rem;
    border-radius:0;
  }
  #contentDes{
    position:absolute;
    left:0;
  }
  .mui-numbox{
        position:absolute;
        right:0.8rem;
        width:50%;
        padding:0;
        border:0;
        top:1.5rem;
        background:#fff;
    }
   .mui-numbox .price{
      display: inline-block;
      position: absolute;
      left:1rem;
      top:0.4rem;
      font-weight: 700;
      color:#fa563d;
      font-size:1rem;
    }
    .mui-numbox .mui-numbox-input, .mui-numbox .mui-input-numbox{
        border-right:0 !important;
        border-left:0 !important;
    }
   .mui-numbox>input{
        width:1.2rem !important;
        margin-top:0.4rem;
        height:1.2rem;

   }
   .mui-numbox>button:nth-child(2){
            left:6rem;
   }
   .mui-numbox>input:nth-child(3){
            margin-left:6rem;
   }
    .mui-numbox>button{
        position:absolute;
        top:0.4rem;
        width:1.2rem;
        height:1.2rem;
        border-radius:50%;
        font-weight: 500;
        font-size: 1.2rem;
        color:#fff;
        background:#2194fe;
    }
     .mui-numbox>button:first-child>span{
         display: inline-block;
         position: relative;
         top:-0.1rem;
     }
    .mui-numbox>button:first-child{
        background:#fff;
        color:#2194fe;
        border:1px #72b2f0 solid;
    }

  .mui-popover{
    left:0 !important;
    border-radius:0 !important;
    width:100%;
    height:15rem;
    z-index:999;
    padding-bottom:3.5rem;
  }
  .mui-bar{
    z-index:9999;
    height:3.875rem;
  }
  .h{
    height:100%;
    width:79%;
    background:rgba(80,80,82,0.95)
  }
  .mui-bar p{
    margin:0;
  }
  .cart{
    width:3rem;
    height:3rem;
    position: relative;
    top:-0.6rem;
    left:0.8rem;
    border-radius:50%;
    background:#444446;
  }
  .cart>div{
    width:2.5rem;
    height:2.5rem;
    left:0.25rem;
    top:0.25rem;
    position: absolute;
    border-radius:50%;
    background:#363636;
  }
  .mui-icon-extra-cart{
    position: absolute;
    top:-0.25rem;
    color:#5f5e63;
  }
  .mui-icon-extra-cart.mcactive{
    color:#fff;
  }
  .cactive{
    background:#3191e8 !important;
  }
  .price{
    position: absolute;
    left:4.5rem;
    top:0.5rem;
  }
  .cartprice{
    color:#fff;
    font-size:1.1rem !important;
  }
  .price>p{
    text-align:left;
    font-size:0.7rem;
  }
  .qs{
    position: absolute;
    top:0;
    right:0;
    width:21%;
    height:100%;
    line-height:3.875rem;
    background:rgba(83,83,85,0.95);
  }
  .qs.qactive{
    background:#37ca72;
    
  }
  .qs>p{
    color:#fff;
    font-size: 0.8rem;
  }
  .dis{
    display:none;
  }
</style>
