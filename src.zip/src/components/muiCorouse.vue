<template>
  <div>
    <div id="slider" class="mui-slider" >
			<div class="mui-slider-group mui-slider-loop">
				<!-- 额外增加的一个节点(循环轮播：第一个节点是最后一张轮播) -->
				<div class="mui-slider-item mui-slider-item-duplicate">
					<a href="#">
						<img src="corouseImage/e5.jpg">
					</a>
				</div>
				<!-- 第一张 -->
				<div class="mui-slider-item">
					<a href="#">
						<img src="corouseImage/e1.png">
					</a>
				</div>
				<!-- 第二张 -->
				<div class="mui-slider-item">
					<a href="#">
						<img src="corouseImage/e3.png">
					</a>
				</div>
				<!-- 第三张 -->
				<div class="mui-slider-item">
					<a href="#">
						<img src="corouseImage/e6.jpg">
					</a>
				</div>
				<!-- 第四张 -->
				<div class="mui-slider-item">
					<a href="#">
						<img src="corouseImage/e4.png">
					</a>
				</div>
				<!-- 第五张 -->
				<div class="mui-slider-item">
					<a href="#">
            <img src="corouseImage/e7.jpg">
					</a>
				</div>
				<!-- 第六张 -->
				<div class="mui-slider-item">
					<a href="#">
						<img src="corouseImage/e5.jpg">
					</a>
				</div>
				<!-- 额外增加的一个节点(循环轮播：最后一个节点是第一张轮播) -->
				<div class="mui-slider-item mui-slider-item-duplicate">
					<a href="#">
           <img src="corouseImage/e1.png">
					</a>
				</div>
			</div>
			<div class="mui-slider-indicator">
				<div class="mui-indicator mui-active"></div>
				<div class="mui-indicator"></div>
				<div class="mui-indicator"></div>
				<div class="mui-indicator"></div>
				<div class="mui-indicator"></div>
				<div class="mui-indicator"></div>
			</div>
		</div>
  </div>
</template>
<script>
export default {
  data(){
    return{}
  },
  mounted(){
   mui.init({
				swipeBack:true //启用右滑关闭功能
			});
		var slider = mui("#slider");
    slider.slider({
         interval: 2000//自动轮播周期，若为0则不自动播放，默认为0；
    });

  },
}
</script>
<style scoped>
.mui-slider .mui-slider-group .mui-slider-item{
	background:#fff;
}
.mui-slider .mui-slider-group .mui-slider-item img {
    height:6rem !important;
    border-radius:5%;
    padding:0 0.9rem;
  }
</style>