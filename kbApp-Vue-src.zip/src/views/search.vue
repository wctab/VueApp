<template>
  <div>
    <header id="header" class="mui-bar mui-bar-nav">
			<router-link to="index" class=" mui-icon mui-icon-left-nav mui-pull-left"></router-link>
      <div class="search">
          <span class="mui-icon mui-icon-search" :class="value==''?'':'closeempty'"></span>
          <input type="text" v-model="value" 
           placeholder="试试搜:彭德蟹" v-focus="true">
            <span class="mui-icon mui-icon-mic" :class="value==''?'':'dis'"></span>
          <span class="mui-icon mui-icon-closeempty" :class="value==''?'dis':''" 
          @click="clear"></span>
           <span class="ss" @click="search">搜索</span>
      </div>
		</header>
    <div id="searchback" :class="value==''?'dis':''">
      <div class="none" :class="searchArr==''?'':'dis'">{{err}}</div>
      <router-link v-for="(item,i) of searchArr" :key="i" :to="item.surl==''?'':item.surl" class="searRouter">
        <span class="mui-icon mui-icon-search"></span>
        <span v-text="`【${item.sname}】`"></span>
        <span v-text="item.addr"></span>
      </router-link>
    </div>
    <div class="searLoaction">
      <div class="searchf">
        <p>搜索发现</p>
        <div @click="loop">
          <span class="mui-icon mui-icon-loop"></span>
          <span>换一组</span>
        </div>
      </div>
      <div class="shop">
        <div class="around">
          <span class="mui-icon mui-icon-location"></span>
          <span>附近的店</span>
        </div>
        <div>
          <router-link to="hmjmf"><span>彭德蟹</span></router-link>
        </div>
        <div v-for="(item,index) of shopdata" :key="index">
          <span v-text="item.sname"></span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return{
      value:"",
      shopdata:[],
      searchArr:[],
      err:""
    }
  },
  created(){
    this.loop()
  },
  methods: {
    clear(){
      this.value=""
    },
    loop(){
      mui.ajax("http://127.0.0.1:4000/shop",{
        data:{},
        type:"get",
        dataType:"json",
        success:(result)=>{
          console.log(result)
          if(result.code==200){
            this.shopdata = result.data;
          }else{
            mui.toast("加载数据出错");
          }
        },
        error:()=>{
          mui.toast("加载数据出错");
        }
      })
    },
    search(){
      if(this.value.trim()!=""){
        console.log(this.value);
        mui.ajax("http://127.0.0.1:4000/shop/search",{
          data:{
            value:this.value
          },
          type:"get",
          dataType:"json",
          success:(result)=>{
            if(result.code==200){
              this.searchArr = result.data
            }else{
              this.err ="o(╥﹏╥)o 没有搜到哦"
            }
          },
          error:()=>{
            mui.toast("搜索出错");
          }
        })
      }
    }
  },
  watch:{
    value(){
      this.search()
    }
  }
}
</script>
<style scoped>
#header{
  height:3.5rem;
  border:0 !important;
  background:#fff;
  box-shadow:0 0 0 #fff!important;
}
.mui-pull-left{
  display: block;
  font-size:1.8rem!important;
  color:#222;
  margin-top:0.3rem !important;
}
  .search{
    width:88%!important;
    position: absolute;
    left:12%;
    top:0.8rem;
    height:2rem;
    z-index:-1;
   
  }

  .mui-icon-search{
    position:absolute;
    font-size:1.2rem !important;
    left:-44%;
    bottom:0.2rem;
  }
  .search input{
    width:80%;
    height:2rem;
    left:0;
    border-radius:2rem;
    font-size: 0.95rem;
    padding-left:2rem;
    position:absolute;
    margin-bottom:0;
    background:#f5f5f5;
    border:0;
  }
  .mui-bar-nav.mui-bar .mui-icon.mui-icon-mic{
    right:23%;
    top:0.3rem;
    z-index:1;
    font-size:1.2rem;
    position: absolute;
    margin:0;
    padding:0;
  }
  .closeempty{
    left:-40%;
  }
  .mui-icon-closeempty{
    left:20%;
    padding:0 !important;
    margin:0 !important;
    top:-0.2rem;
  }
  .ss{
     position: absolute;
     right: 6%;
     top:0.3rem;
     font-size:1rem;
  }
  #searchback{
    position: absolute;
    width:100%;
    top:3.5rem;
    min-height:15rem;
    background:#fff;
  }
  .searRouter{
    position: relative;
    display: inline-block;
    width:100%;
    padding-right:0.5rem;
    padding-left:2rem;
    color:#333;
    font-size:0.95rem;
    overflow: hidden;
    height:3rem;
    word-wrap: nowrap;
    line-height:3rem;
    text-align:left;
  }
  .searRouter .mui-icon-search{
    left:1rem;
    bottom:0.9rem;
    color:#999;
    font-weight:700;
  }
  .searRouter>span:nth-child(2){
    display: inline-block;
    margin-left:0.8rem;
  }
  .searRouter>span:nth-child(3){
    word-wrap: nowrap;
  }

  .none{
    color:#666;
    font-size:1rem;
  }


  .searLoaction{
    margin-top:4.5rem;
    padding:0 0.8rem;
  }
  .searchf{
    display:flex;
    height:2rem;
    font-size:0.8rem;
    margin-top:0.9rem;
    margin-bottom:0.4rem;
    align-items: center;
    color:#999;
    justify-content:space-between;
  }
  .searchf p{
    margin-bottom:0;
    color:#999;
    font-size:0.8rem;
    letter-spacing: 0.1rem;
  }
  .mui-input-clear{
    right:20%;
  }
  .searchf>div>.mui-icon-loop{
    font-size:1.1rem;
    margin-right:0.3rem;
  }
  .dis{
    display:none;
  }
  .shop{
    margin-top:-0.5rem;
  }
  .around>span,.mui-icon-location{
    color:#fe5900 !important;
    }
  .shop p,.shop span{
    margin:0;padding:0;
    color:#000;
    font-size:0.90rem;
  }
  .shop>div{
    float: left;
    height:2rem;
    line-height: 2rem;
    background:#fff;
    padding:0 0.5rem;
    margin-right:0.5rem;
    margin-top:0.5rem;
    border:1px #ddd solid;
    box-sizing:border-box;
  }
  .shop::after{
    content:"";
    display:block;
    clear:both;
  }
</style>
