<template>
    <div>
        <header>
           <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>
           <span class="dname">彭德蟹黄焖鸡米饭(人民景德路35号店)</span>
           <router-link to="/search"><span class="mui-icon mui-icon-search"></span></router-link>
           <img class="tao" src="@/components/icon/taobao.jpg">
        </header>
        <div class="h_container">
          <div class="mui-scroll-wrapper">
            <div class="mui-scroll">
                <div class="content_h">
                   <img class="jmf_h_img" src="img/jmf/jmf_h_img.png">
                   <div class="h_hh">
                      <span class="h_dname">彭德蟹黄焖鸡米饭(人民景德路35号店)</span>
                      <img class="h_right" src="@/components/icon/right.png">
                   </div>
                   <p class="h_appraise">评价4.5 月售3426单 蜂鸟快送约39分钟</p>
                   <p class="h_mj"><span>&yen;2</span>  满42可用 领取</p>
                   <div class="h_yh">
                    <span>满减</span>
                    <span>满18减10，满28减16，满53减27，满80减40</span>
                    <span>4个优惠</span>
                    <img src="@/components/icon/downb.png">
                   </div>
                   <p class="gg">
                     <span>公告：本店全年无休，24小时在线</span>
                   </p>
                </div>
                <div class="mui-content">
                    <div id="slider" class="mui-slider mui-fullscreen">
                        <div id="sliderSegmentedControl" class="mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
                                <a class="mui-control-item mui-active" href="#dc">
                                    点餐
                                </a>
                                <a class="mui-control-item" href="#contact">
                                    评价
                                </a>
                                <a class="mui-control-item" href="#boss">
                                    商家
                                </a>
                        </div>
                        <div id="sliderProgressBar" class="mui-slider-progress-bar mui-col-xs-4 ">
                            <span class="ProgressBarSpan"></span>
                        </div>
                        <div class="mui-slider-group">
                            <div id="dc" class="mui-slider-item mui-control-content">
                                <div id="scroll1" class="mui-scroll-wrapper">
							        <div class="mui-scroll">
                                        <!-- 商家推荐 -->
                                        <div class="tuij">
                                            <p>商家推荐</p>
                                            <div id="businesses" class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
                                                <div class="mui-scroll">
                                                    <div class="item" v-for="(item,i) of imgUrl" :key="i">
                                                        <a class="mui-control-item" href="javascript:;">
                                                            <img class="purl_img" :src="`${item}`" alt="">
                                                            <p class="purl_c">
                                                                <span>黄焖鸡大份+土豆+黄焖豆腐</span>
                                                            </p>
                                                            <p class="purl_f"><span>月售3426,好评率100%</span></p>
                                                        </a>
                                                        <div id="btn_p">
                                                            <span class="purl_p">￥17.88</span>
                                                            <div class="mui-numbox">
					                                            <button class="mui-btn mui-btn-numbox-minus" 
                                                                type="button" :class="value==0?'count':''" ><span>-</span></button>
					                                            <input :class="value==0?'count':''" class="mui-input-numbox" type="number" 
                                                                v-model="value" 
                                                                />
					                                            <button class="mui-btn mui-btn-numbox-plus" 
                                                                type="button" ><span>+</span></button>
                                                            </div>
                                                        </div>
                                                    </div>	
                                                </div>
                                            </div>
                                        </div>
                                        <!-- end -->
                
                                        <!-- 侧滑start-->
                                       <div class="cehua">
                                            <div class="mui-col-xs-3">
                                                <div id="segmentedControls" class="mui-segmented-control mui-segmented-control-inverted mui-segmented-control-vertical">
                                                   <a v-for="(item,i) of tc" :key="i" style="width:100%;text-align:left;padding-left:0.8rem;" class="mui-control-item" :href="`#content${i}`" :class="i==0?'mui-active':''"><span>{{item}}</span></a>
                                                </div>
                                            </div>
                                            <div id="segmentedControlContents" class="mui-col-xs-9" style="border-left: 1px solid #c8c7cc;">
                                                <div v-for="(item,i) of products" :key="i" :id="`content${i}`" class="mui-control-content mui-active">
                                                    <ul class="mui-table-view">
                                                        <li v-for="(pro,j) of item" :key="j" class="mui-table-view-cell"><a class="list" herf="javascript:;">
                                                            <div class="listimg"> 
                                                                <img :src="`http://localhost:4000/${pro.imgUrl}`"/> 
                                                            </div>
                                                            <div><p class="title title2" v-text="pro.title"></p><p class="sell sell2" v-text="pro.sell"></p>
                                                            <div id="btn_p" class="pp">
                                                            <span class="purl_p" v-text="`￥${pro.price}${i==0?'起':''}`"></span>
                                                            <div class="mui-numbox">
					                                            <button class="mui-btn mui-btn-numbox-minus" 
                                                                type="button" :class="pro.count==0?'count':''" @click="reduce(i,j)"><span>-</span></button>
					                                            <input :class="pro.count==0?'count':''" class="mui-input-numbox" type="number" 
                                                                v-model="pro.count" 
                                                                />
					                                            <button class="mui-btn mui-btn-numbox-plus" 
                                                                type="button" @click="add(i,j)"><span>+</span></button>
                                                            </div>
                                                        </div></div>
                                                        </a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>

                                    <!-- 侧滑end -->
							        </div>
                                </div>
                            </div>
                            <div id="contact" class="mui-slider-item mui-control-content">
                                <div id="scroll2" class="mui-scroll-wrapper">
							        <div class="mui-scroll">
                                        22
							        </div>
                                </div>
                            </div>
                            <div id="boss" class="mui-slider-item mui-control-content">
                                <div id="scroll3" class="mui-scroll-wrapper">
							        <div class="mui-scroll">
                                        33
							        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            
            </div>
           </div>
        </div>
        <hmfooter></hmfooter>
        <div style="display:none">{{total}}</div>
    </div>
</template>
<script>
import hmfooter from "@/components/hmfooter.vue"
export default {
    data(){
        return{
            value:0,
            imgUrl:["img/jmf/t1.png","img/jmf/t2.png","img/jmf/t3.png","img/jmf/t4.png","img/jmf/t1.png"],
            tc: ["超值套餐","黄焖鸡米饭","美味砂锅饭","商务套餐","美味浇盖饭",
                "炒粉面粉","汤粉面","营养粉面","原湖炖品","开心加料","饮料"],
            products:[],
            proCart:[]
        }
    },
    created(){
        this.load();
    },
    mounted(){
        mui('.mui-scroll-wrapper').scroll({
	        scrollY: true, //是否竖向滚动
            scrollX: false, //是否横向滚动
            startX: 0, //初始化时滚动至x
            startY: 0, //初始化时滚动至y
            indicators: false, //是否显示滚动条
            deceleration:0.0006, //阻尼系数,系数越小滑动越灵敏
            bounce: false //是否启用回弹
        });

        mui.init({
				swipeBack: true //启用右滑关闭功能
			});
            // 购物车

              
    
    },
    updated() {
        // total();
    },
    computed: {
        total(){
            var total=0;
            var arr=[]
            var products =this.$store.state.selProducts;
            for(var i =0;i<products.length;i++){
                for(var j=0;j<products[0].length;j++){
                    var count = products[i][j].count;
                    var price = products[i][j].price;
                    total += count*price;
                    //console.log("计算："+total)
                    this.$store.state.total = total.toFixed(2);
                    if(products[i][j].count>0){
                        //console.log("多少",products[i][j].count)
                        arr = arr.concat(products[i][j])
                        //console.log("数组",arr)
                        this.$store.state.cartProducts = arr;
                    }
                }
            }
        }
    },
    methods:{
        reduce(i,j){
            console.log(i,j);
            var count = this.products[i][j].count;
            var price = this.products[i][j].price;
            if(count==0){
                count=0
            }else{
                count--
                this.$store.commit("sub")
            }
            console.log(count)
            this.products[i][j].count = count

            // //数据库--
            // price = price*count;
            // var proCart={};
            // proCart.pid = this.products[i][j].hid;
            // proCart.pi = i;
            // proCart.pj = j;
            // proCart.count = count;
            // proCart.price=price;
            // proCart.title = this.products[i][j].title;
            // proCart.purl = this.products[i][j].imgUrl;
            // console.log(proCart);
 
        },
        add(i,j){
            var all=0;
            var proCart={};
            console.log(i,j);
            this.$store.commit("increment");
            var count = this.products[i][j].count;
            var price = this.products[i][j].price;
            count++;
            price = price*count;
            this.products[i][j].count = count;




            
        },
        addCart(arr){

        },
        load(){
            mui.ajax("http://127.0.0.1:4000/jmf",{
                data:{},
                type:"get",
                dataType:"json",
                success:(result)=>{
                    // console.log(result);
                    if(result.code==200){
                        this.products = result.data;
                    }
                    console.log(this.products);
                },
                error:()=>{
                    mui.toast("加载数据出错")
                }
            })
        }
    },
    watch: {
        products(){
            this.$store.state.selProducts = this.products;
        }
    },
    components:{
        hmfooter
    }
}
</script>
<style scoped>
    header{
        text-align:left;
        width:100%;
        height:3rem;
        line-height:3rem;
        background-color:#fff;
        position:fixed;
        z-index:9999;
    }
    .mui-action-back{
        color:#000;
        line-height:3rem;
        position:absolute;
        left:2%;
    }
    .mui-icon-search{
        position:absolute;
        top:0.8rem;
        right:15%;
        color:#666;
        font-weight:700;
    }
    .tao{
         position:absolute;
         width:7%;
         top:0.8rem;
         right:5%;
    }
    .dname{
        position:absolute;
        left:15%;
        display:inline-block;
        font-size:1.0425rem;
        width:12rem;
        height:3rem;
        white-space:nowrap;
        overflow:hidden;
        color:#222;
        text-overflow:ellipsis;
    }
    .h_container{
        top:3rem;
        position:relative;
        min-height:819px;
        height:100%;
        overflow-y: auto;
        background:#fff;
        margin-bottom:5rem;
    }
    .content_h{
        height:258px;
        text-align:center;
    }
    .content_h p{
        margin-bottom:0;
    }
    .jmf_h_img{
        width:100%;
    }
    .h_hh{
        position:relative;
    }
    .h_dname{
        display:inline-block;
        margin-top:0.8rem;
        color:#333;
        font-weight:700;
        font-size:1rem;
        width:14rem;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
    }
    .h_right{
        width:2%;
        position:absolute;
        top:1rem;
    }
    .h_appraise{
        font-size:0.6rem;
        margin-top:0.3rem;
    }
    .h_mj{
        margin:0.35rem 30% ;
        width:8rem;
        font-size:0.7rem;
        text-align:center;
        height:1.3rem;
        line-height:1.3rem;
        background:#fef4f3;
        color:#5b1704;
    }
    .h_mj span{
        font-size:1rem;
        font-weight:700;
    }
    .h_yh{
        position:relative;
        margin-top:0.35rem;
        width:18rem;
        font-size:0.7rem;
        white-space:nowrap;
        height:1.2rem;
        left:15%;
    }
    .h_yh span:nth-child(1){
         position:absolute;
         left:0;
         color:#fff;
         width:2rem;
         height:1.2rem;
         background:#ef7373;
    }
    .h_yh span:nth-child(2){
        position:absolute;
        left:2.2rem;
        width:10rem;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
    }
    .h_yh span:nth-child(3){
        position:absolute;
        left:12.4rem;
        color:#999;
    }
    .h_yh img:nth-child(4){
        position:absolute;
        left:15.4rem;
        width:3%;
        top:0.4rem;
    }
    .gg{
       margin-top:0.3rem;
       font-size:0.7rem;
       color:#ccc;
       position:relative; 
    }
    .gg span{
        position:absolute;
        left:15%;
    }

    .mui-fullscreen{
       top:258px;
       min-height:560px;
       height:100%;
       background:#fff;
       overflow-y: auto;
    }
    .mui-segmented-control.mui-segmented-control-inverted ~ .mui-slider-progress-bar{
        background:#fff;
    }
    .ProgressBarSpan{
		display:inline-block;
		position:absolute;
		top:0;
		left:42%;
		width:0.8rem;
		height:0.15rem;
		background:#007aff;
	}
    .mui-segmented-control.mui-segmented-control-inverted .mui-control-item.mui-active{
        color:#000;
    }
    .tuij{
        padding-left:0.85rem;
    }
    .tuij > p{
        color:#000;
        margin-top:0.5rem;
        font-size:1rem;
        text-align: left;
    }
    #businesses{
        width:100%;
        height:12rem;
    }
    #businesses .mui-scroll{
        display: flex;
    }
   #businesses .mui-control-item{
       width:8rem;
       height:10rem;
   }
    .mui-slider .mui-slider-group .mui-slider-item img,.purl_img{
        margin-left:-1.2rem;
        width:8rem;
        height:7rem;
    }
    .item{
        position:relative;
        text-align:left;
    } 
    .item p{
        margin-bottom:0;
    }
    .item .purl_c{
        position: absolute;
        width:8rem;
        top:6.78rem;
        color:#222;
        left:0;
        overflow: hidden;
        white-space:nowrap;
        text-overflow: ellipsis;

    }
    .item .purl_c span,.item .purl_f span{
        padding-left:0.225rem;
    }
    .item .purl_f{
        position: absolute;
        left:0;
        font-size:0.6rem;
    }
    #btn_p{
        width:100%;
        position:relative;
    }
    .purl_p{
        width:50%;
        font-size: 0.9rem;
        margin-left:0.3rem;
        color:#f05840;
    }
    .mui-numbox{
        position:absolute;
        right:0;
        width:50%;
        padding:0;
        border:0;
        background:#fff;
    }
    .mui-numbox .mui-numbox-input, .mui-numbox .mui-input-numbox{
        border-right:0 !important;
        border-left:0 !important;
    }
   .mui-numbox>input{
        width:1.2rem;
        height:1.2rem;

   }
    .mui-numbox>button{
        position:absolute;
        width:1.2rem;
        height:1.2rem;
        border-radius:50%;
        font-weight: 500;
        font-size: 1.2rem;
        color:#fff;
        background:#2194fe;
    }
     .mui-numbox>button:first-child>span{
         display: inline-block;
         position: relative;
         top:-0.1rem;
     }
    .mui-numbox>button:first-child{
        background:#fff;
        color:#2194fe;
        border:1px #72b2f0 solid;
    }
    .count{
        display:none !important;
    }

    #segmentedControls{
        width: 100%;
        float: left;
    }
    #segmentedControlContents{
        width:75%;
        float:right;
    }
    .mui-col-xs-3{
        position: fixed;
       
    }
    .list{
        width:100%;
        position:relative;
        height:6.8rem;
        display:block;
    }
   .list>div:nth-child(1){
        position:absolute;
        left:0;
       width:20%;
   }
    .list>div:nth-child(2){
        position:absolute;
        right:0;
        width:80%;
    }
    .mui-table-view-cell{
        padding:0 0 0.95rem 0.5rem;
    }
    .mui-table-view-cell > a:not(.mui-btn){
        margin:0;
    }
    .listimg>img{
        width:100%;
    }
    #btn_p.pp{
        position:absolute;
        height:2rem;
        line-height:2rem;
        top:5rem;
        left:2rem;
        width:80%;
    }
    #btn_p.pp>span{
        position:absolute;
        left:0;
    }
   #btn_p.pp .mui-numbox>button{
       top:0.4rem;
   }
   .list>div:nth-child(2) .title2{
       position:absolute;
       color:#000;
       font-size: 0.9rem;
       left:3.5rem;
       width:8rem;
        overflow: hidden;
        white-space:nowrap;
        text-overflow: ellipsis;
       text-align: left;
       height:1.5rem;
       line-height:1.5rem;
   }
   .list>div:nth-child(2) .sell2{
       text-align: left;
       font-size: 0.7rem;
       position:absolute;
       height:1.5rem;
       left:3.5rem;
       line-height:1.5rem;
       top:1.5rem;
   }
</style>