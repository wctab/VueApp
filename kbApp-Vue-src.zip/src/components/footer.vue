  <template>
    <div>
      <nav class="mui-bar mui-bar-tab ">
        <router-link  class="mui-tab-item" :class="num==1?mue:''" to="/index">
          <span class="mui-icon mui-icon-home"></span>
          <span class="mui-tab-label">首页</span>
        </router-link>
        <router-link  class="mui-tab-item" :class="num==2?mue:''" to="/live">
          <span class="mui-icon mui-icon-pengyouquan"></span>
          <span class="mui-tab-label">生活圈</span>
        </router-link>
        <router-link  class="mui-tab-item" :class="num==3?mue:''" to="/order">
          <span class="mui-icon mui-icon-extra-order"></span>
          <span class="mui-tab-label">订单</span>
        </router-link>
        <router-link   class="mui-tab-item" :class="num==4?mue:''" to="/myhome">
          <span class="mui-icon mui-icon-person"></span>
          <span class="mui-tab-label">我的</span>
        </router-link>
		  </nav>
    </div>
  </template>      
<script>
export default {
  data(){
    return{
      mue:"mui-active",
      num:1
    }
  },
  created(){
    this.num = this.$store.state.num;
    mui('body').on('tap','a',function(){
      window.top.location.href=this.href;
    });
  },
  mounted(){
  },
  methods:{
      /*index(){
        this.$router.push("/")
      },
      live(){
        this.$router.push("/live")
      },
      order(){
        this.$router.push("/order")
      },
      myhome(){
        this.$router.push("/myhome")
      },*/
    }
}
</script>
<style scoped>
  .mui-tab-item.mue-active{
    color:#ff5500;
  }
</style>
